<?php
include "koneksi.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>

    <header style="text-align: center;">
        <h2 class="logo"><span>Formulir</span>
    </header>
    

    <table class="styled-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Jurusan</th>
                <th>Email</th>
                <th>Password</th>
                <th>Jenis Kelamin</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
            <?php
          $sql2 = "select * from data order by 'id' desc";
          $q2 = mysqli_query($koneksi,$sql2);
          while($r2 = mysqli_fetch_array ($q2)){
            $nama = $r2['nama'];
            $jurusan = $r2['jurusan'];
            $email = $r2['email'];
            $password = $r2['password'];
            $jeniskelamin = $r2['jeniskelamin'];
            $lahir = $r2['lahir'];
            $alamat = $r2['alamat']; }
          ?>
            <tr>
                <th scope="row"> <?php echo $nama ?> </th>
           <th scope="row"> <?php echo $jurusan ?> </th>
           <th scope="row"> <?php echo $email ?> </th>
           <th scope="row"> <?php echo $password ?> </th>
           <th scope="row"> <?php echo $jeniskelamin ?> </th>
           <th scope="row"> <?php echo $lahir ?> </th>
           <th scope="row"> <?php echo $alamat ?> </th>
          
            </tr>
        </tbody>
    </table>

      <main>
        <input type="checkbox" id="check">
        <label for="check">
            <i class="fas fa-bars" id="btn"></i>
            <i class="fa fa-arrow-right" id="open"></i>
        </label>
        <div class="sidebar">
            <div class="top">
                Marcel Ong
            </div>  
            <ul>
                <li><a class="#" href="index.html"><i class="fa fa-home"></i> Home</a></li>
                <li><a class="#" href="form.php"><i class="fa fa-shopping-basket"></i> Isi Data</a></li>
                <li><a class="#" href="datamahasiswa.php"><i class="fa fa-shopping-bag"></i> Data Mahasiswa</a></li>
            </ul>
        </div>
    </main>

</body>

<footer style="text-align: center; position: fixed; bottom: 1px; background-color:  #000000; color: #ffffff; height: 40px; width: 100%;"
    <p>&copy; 2023 Marcel Ong</p>
</footer>
</html>